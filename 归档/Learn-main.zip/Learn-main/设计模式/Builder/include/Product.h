/*
 * @Descripttion: 
 * @version: 
 * @Author: 秦武胜
 * @Date: 2021-11-21 19:30:38
 * @LastEditors: 秦武胜
 * @LastEditTime: 2021-11-26 17:06:56
 */
#ifndef _PRODUCT_H_
#define _PRODUCT_H_
#include<iostream>
using namespace std;
class Product
{
private:
public:
    Product();
    ~Product();

    string ProductA();
};

#endif // _PRODUCT_H_
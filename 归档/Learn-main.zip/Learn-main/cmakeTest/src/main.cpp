/*
 * @Descripttion: 
 * @version: 
 * @Author: 秦武胜
 * @Date: 2021-11-21 19:23:02
 * @LastEditors: 秦武胜
 * @LastEditTime: 2021-11-21 19:23:03
 */
#include <iostream>
using namespace std;
int main()
{

    cout << "hell world" << endl;
    return 0;
}
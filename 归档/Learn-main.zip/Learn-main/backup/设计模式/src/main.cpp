/*
 * @Descripttion: 
 * @version: 
 * @Author: 秦武胜
 * @Date: 2021-11-21 17:33:56
 * @LastEditors: 秦武胜
 * @LastEditTime: 2021-11-21 20:22:19
 */
#include<iostream>
#include"Product.h"
int main()
{

    Product p;
    std::cout<<"hello world"<<std::endl;
    return 0;
}
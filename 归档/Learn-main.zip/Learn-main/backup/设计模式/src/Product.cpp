/*
 * @Descripttion: 
 * @version: 
 * @Author: 秦武胜
 * @Date: 2021-11-21 19:32:48
 * @LastEditors: 秦武胜
 * @LastEditTime: 2021-11-21 19:34:18
 */
#include"Product.h"
#include<iostream>
using namespace std;
Product::Product()
{
cout<<"I am Product"<<endl;
}

Product::~Product(){

}
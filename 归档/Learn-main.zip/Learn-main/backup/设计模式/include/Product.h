/*
 * @Descripttion: 
 * @version: 
 * @Author: 秦武胜
 * @Date: 2021-11-21 19:30:38
 * @LastEditors: 秦武胜
 * @LastEditTime: 2021-11-21 19:31:42
 */
#ifndef _PRODUCT_H_
#define _PRODUCT_H_

class Product
{
private:
public:
    Product();
    ~Product();
};

#endif // _PRODUCT_H_
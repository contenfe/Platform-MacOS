此为MAC / LINUX 环境项目配置

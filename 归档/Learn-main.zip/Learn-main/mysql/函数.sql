# 函数

/*

概念：类似于Java中的方法

分类：
	1.单行函数
	字符函数、数学函数、日期函数、其他函数、流程控制函数
	2.分组函数
	统计函数
*/

# 1.字符函数 索引从1开始
# length
SELECT	LENGTH("掌声");
SELECT LENGTH("123");

SHOW VARIABLES LIKE '%char%';# 显示使用的字符集

# concat 拼接字符串
SELECT CONCAT(last_name,'_',first_name) AS 姓名 FROM employee;

# upper lower
SELECT UPPER('joB');
SELECT LOWER("SAj");

# substr substring 截取字符串
SELECT SUBSTR("阿斯顿水岸东方",4) 'out'; -- 水岸东方
SELECT SUBSTR("阿斯顿水岸东方",2,4) 'out'; -- 斯顿水岸
SELECT SUBSTR("阿斯顿水岸东方") 'out'; -- 

# instr 找到第一次出现的位置
SELECT INSTR("花茶一件s一件",'一件') 'out';

# trim 去空格,前后
SELECT LENGTH(TRIM('adfasd'));
SELECT TRIM('a' FROM 'aaaa擦aaaaaaa茶aaaaaaaassaaaaaaaaaaaaaaa') 'out';

# lpad rpad 用指定的字符填（*）充字符串填充
SELECT LPAD("道",8,'*');
SELECT RPAD("天",8,'*');

# replace 替换
SELECT REPLACE("我们是一家人，是一个团体，是羁绊",'家人','联系人');

# 数学函数

# round 四舍五入
SELECT ROUND(3.23);
SELECT ROUND(3.7);

SELECT ROUND(3.789,2);-- 3.79 ,小数点后保存两位，

# ceil 向上取整 ,返回>=该参数的最小整数
SELECT CEIL(1.00);-- 1
SELECT CEIL(1.56);-- 2
SELECT CEIL(2.00);-- 2

# floor 向下取整 ,返回<=该参数的最小整数
SELECT FLOOR(1.00);-- 1
SELECT FLOOR(1.56);-- 1
SELECT FLOOR(2.00);-- 2

# truncate 截断
SELECT TRUNCATE(1.8999,1); -- 1.8


# mod 取余
-- mod(a,b) : a-a/b*b  
SELECT MOD(10,2); -- 0


# 日期函数
# now 返回当前系统日期+时间
SELECT NOW();

# curdate 返回当前系统日期，不包含时间
SELECT CURDATE();

# curtime 返回当前时间，不包含日期
SELECT CURTIME();

# 可以获取指定的部分，年、月、日、小时、分钟、秒
# year 
SELECT YEAR(NOW()) 年;
# month
SELECT MONTH(NOW()) 月;
# day
SELECT DAY(NOW()) 日;
-- ....


# str_to_date 将字符通过指定的格式转换成日期
SELECT STR_TO_DATE("1999-12-20",'%Y-%c-%d') AS 日期;-- 1999-12-20

# 
SELECT * FROM employee WHERE hirdate = '1992-4-';
SELECT * FROM employee WHERE hirdate = STR_TO_DATE(s,f);-- 重Java获取查询的信息

# date_format 将日期转换成字符
SELECT DATE_FORMAT(NOW(),"%Y年%m月%d日") AS 'out';


# 其他函数
SELECT VERSION(); -- 当前版本
SELECT DATABASE(); -- 当前数据库
SELECT USER(); -- 当前用户


# 流程控制函数
# if 函数：if else 的效果
SELECT IF(10>4,'大','小'); -- 大
SELECT IF(10<4,'大','小'); -- 小

# case: switch case 的结果 ,有if - else if的效果
/*
swich(){
case 1:
case 2:
default:
}
-------------------------------
case 表达式
when 常量1 then 语句或值；
when 常量1 then 语句或值；
... 
else  语句或值；
end
*/
SELECT CASE(

)

######################################################



# 分组函数

/*
组函数

分类
sum 求和、avg 平均值 max .....
*/

SELECT SUM(salary) FROM employee;
SELECT COUNT(salary) FROM employee;
SELECT COUNT(*) FROM employee; -- 效率最高

-- 分组函数 null 不参与计算
-- 与distinct 搭配

# 和分组函数一同查询的字段有限制 ,要求式group by后的字段
SELECT AVG(salary),employee_id FROM employee;

# datediff 相差多少天
SELECT DATEDIFF('1999-12-20','1890-1-1');

# 查询各个部门的薪资 group by 

SELECT MAX(salary),job_id FROM employee GROUP BY job_id;

# 添加筛选条件
# 查询邮箱中包含a字段，每个部门的平均工资
SELECT AVG(salary),department_id FROM employee  WHERE email LIKE '%a%'
 GROUP BY department_id
 ORDER BY DESC;
 
 
 SELECT AVG(salary),department_id FROM employee  WHERE email LIKE '%a%'
 GROUP BY department_id,job_id
 ORDER BY DESC;
 
 # 分组后添加筛选条件
 # having
 SELECT AVG(salary),department_id FROM employee  WHERE email LIKE '%a%'
 GROUP BY department_id
 HAVING MIN(salary)>50;
 ORDER BY DESC;
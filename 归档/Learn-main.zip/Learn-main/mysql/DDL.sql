# DDL语言

/*

	数据定义语言
	
	库和表的管理
	
	1.库的管理
	创建、修改、删除
	2.表的管理
	创建、修改、删除

创建：create
修改：alter
删除：drop

*/

# 1.库的管理

/*
	语法：create database 库名;

*/

CREATE DATABASE stuManger;

CREATE DATABASE IF NOT EXISTS stuManger;

# 2.库的修改
/*
	rename database 库名 to 新库名
*/

RENAME DATABASE stuManger TO Managers;


# 更改字符集
ALTER DATABASE stuManger CHARACTER SET gbk;


# 库的删除
DROP DATABASE IF EXISTS stuManger;



# 二.表的管理
/*
	create table 表名(
		列名 列的类型（【（长度） 约束】）
		...
	
	);


*/

DESC dao;


# 表的修改 : alter table 表名 ADD|DROP|MODIFY|CHANGE COLUMN ...

#	修改列名
/*
 alter table 表名 change column 列名 新列名 类型;


*/
ALTER TABLE dao CHANGE COLUMN id main_id VARCHAR(10);
#	修改列的类型或约束
/*
	alter table 表名 modify column 列名 类型
*/
ALTER TABLE dao MODIFY COLUMN main_id INT;

# 增加新列
/*
	alter table author add column 列名 类型

*/
ALTER TABLE dao ADD COLUMN phone VARCHAR(11);
DESC dao;
# 删除列
/*
	alter table 表名 drop column 列名

*/
ALTER TABLE dao DROP COLUMN adress ;

# 修改表名
/*
alter table 表名 rename to 新表名
*/
ALTER TABLE dao RENAME TO xin;

# 表的删除
CREATE TABLE tst(id INT);
DROP TABLE tst;

SHOW xin;


DROP TABLE dao1;

# 表的复制

# 仅仅复制表的结构
/*
	create table 复制表 like 被复制1表名
*/
CREATE TABLE stu LIKE stud;

# 复制表结构和数据
/*
	create table 复制表
	select * from 被复制表、
*/

CREATE TABLE dao 
SELECT * FROM stud;

# 只复制部分
/*
CREATE TABLE 复制表 
SELECT * FROM 被复制表
where 筛选条件
*/
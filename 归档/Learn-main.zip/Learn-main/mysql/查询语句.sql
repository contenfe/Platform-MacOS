# DQL
# 基础查询
/*
	快捷建，格式化：F12

*/

# 查询所有字段
SELECT * FROM job;

# 查询单个字段
SELECT jname FROM job;

# 查询多个字段
SELECT jname,description FROM job;

SELECT `jname`,`description` FROM `job`;

# 查询常量
SELECT 100;
SELECT 'jname';

# 查询表达式
SELECT 100*1;

# 查询函数
SELECT VERSION();

# 起别名
SELECT 100*2 AS 结果;
SELECT 20*3 结果
SELECT 90 AS "out put";


# 去重
SELECT DISTINCT department_id FROM employee;

# +号作用: 当两个字符都为数值型，则做加法运算，
#  其中为字符型且能转换成数字，则相加，否则将转换为0
# 只要一方为null，结果为null
SELECT last_name + first_name AS 结果 FROM employee;

# 连接
SELECT CONCAT(last_name,first_name) AS 姓名;


# ifnull 函数，如果是null,返回0
SELECT IFNULL(last_name,0) AS 结果,
	last_name 答案;
	
# 条件查询
/*
	1.按条件表达式筛选
		>,<,!= <>,=,>=,<=
	2.按逻辑表达式筛选
		&&,||,!
		and or not
	3.模糊查询
		like,
		% 任意多个字符，包含0个字符
		_ 任意单个字符
		between and
		in
		判断某字段的值是否属于in列表中的某一项
		is null
		判断空值
		is not null
		is null
		is
		相当于 <=>
		
*/
SELECT last_name FROM employee WHERE last_name>0;
SELECT last_name FROM employee WHERE last_name!=0;

SELECT last_name FROM employee WHERE last_name>0 AND first_name<0;
SELECT last_name FROM employee WHERE last_name>0 OR first_name<0;
SELECT last_name FROM employee WHERE NOT(last_name>0 AND sal>0) OR first_name<0;


SELECT last_name FROM employee WHERE last_name LIKE '%a%';# %通配符 *
# 查询员工中第3个字符为e,第5个字符为a的员工名和工资
SELECT 
  last_name,
  salary 
FROM
  employee 
WHERE last_name LIKE '__e_a%';
# 查询员工中第3个字符为e,第4个字符为_ 第5个字符为a的员工名和工资
SELECT 
  last_name,
  salary 
FROM
  employee 
WHERE last_name LIKE '__e\_a%';

SELECT last_name FROM employee WHERE last_name BETWEEN 100 AND 200;


SELECT 
  last_name,
  salary 
FROM
  employee 
WHERE
  job_id IN('t','d','da');
  #job_id IN('t','d','da_%');不可以 
  
SELECT 
  last_name,
  salary 
FROM
  employee 
WHERE
  salary IS NULL;
  

/*
	排序
	order by 排序列表 【asc|desc】
	1. asc 代表升序，desc 代表降序，默认升序
*/
#
SELECT 
  last_name,
  salary 
FROM
  employee 
WHERE
  salary IS NOT NULL ORDER BY salary DESC;

#  
SELECT 
  last_name,
  salary 
FROM
  employee 
WHERE
  ORDER BY salary DESC;
  
#
SELECT 
  last_name,
  salary 结果
FROM
  employee 
WHERE
  ORDER BY 结果 DESC; 
  
# 工资升序，员工编号降序,按多个字段排序
SELECT 
  last_name,
  salary 
FROM
  employee 
WHERE
  ORDER BY salary ,employee_id DESC;
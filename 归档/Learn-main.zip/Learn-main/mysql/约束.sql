# 约束

/*
含义：限制字段，保证数据准确性

分类：6大类
	not null ：非空
		比如 姓名，学号
	default:默认 ，用于保证该字段有默认值
		比如性别
	primary key: 主键用于保证字段具有唯一性，并且非空
		比如学号、身份证
	unique:唯一，用于保证该字段的值具有唯一性，可以为空
		比如座位号
	check: 检查约束【mysql中不支持】
		性别只能是男或女
	foreign key: 外键，用于限定两个表的关系，用于保证该字段必须来自主表的关联列的值
		在从表添加约束，引用主表中某列的值
		插入数据先插入主表，删除数据先删除从表
		
		
		
	添加约束的时间：
	1.创建表时
	2.创建约束
	约束的添加分类
	列级约束
		六大约束都支持，外键没有效果
	表级约束
		除了非空，默认，其他都支持
		【constraint 约束名】 约束类型(字段名)
*/

/*
create table yuesu(
	字段名 字段类型 约束
	
);

*/


CREATE DATABASE tst;

CREATE TABLE yue(

	id INT PRIMARY KEY,
	stuName VARCHAR(20) NOT NULL,
	gender CHAR(1) CHECK(gender='男'OR gender='女'),
	seat INT UNIQUE,
	age INT DEFAULT 18,
	majorid INT REFERENCES major(id) # 外键
);

CREATE TABLE major(
	id INT PRIMARY KEY,
	majorName VARCHAR(20)
);

SHOW INDEX FROM yue; -- 查看索引


# 添加标记约束
	
	
CREATE TABLE yue(

	id INT ,
	stuName VARCHAR(20),
	gender CHAR(1),
	seat INT,
	age INT ,
	majorid INT,
	
	CONSTRAINT pk PRIMARY KEY(id),# 添加主键
	CONSTRAINT uq UNIQUE(seat),
	CONSTRAINT ck CHECK(gender='男'OR gender='女'),
	CONSTRAINT fk_yue_major FOREIGN KEY(majorid) REFERENCES major(id)
	
	
);

# 
ALTER TABLE yue MODIFY COLUMN age INT NOT NULL;
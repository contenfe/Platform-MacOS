# 标识列
/*
	有称为自增长列
	可以不用手动的插入值，系统提供默认的序列值

*/

# 1.创建表时设置标识列
DROP TABLE IF EXISTS tab_identity;
CREATE TABLE tab_identity(
	id INT PRIMARY KEY AUTO_INCREMENT,
	NAME VARCHAR(20) DEFAULT 'a'
);

INSERT INTO tab_identity (NAME)
VALUES("name");

INSERT INTO tab_identity (NAME)
VALUES("dao");

INSERT INTO tab_identity
VALUES(NULL,"三");

INSERT INTO tab_identity
VALUES(NULL,NULL);

INSERT INTO tab_identity 
VALUES(NULL);

SELECT * FROM tab_identity;

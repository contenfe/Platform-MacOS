# DML语言

/*
插入：insert
修改：update
删除：delete

*/

# 插入语句
/*
语法一：
insert into 表名（列名，...)
values(值1，...);

优点：可以插入多行,方法2不支持，
      支持子查询，方法2不支持
      insert into stud
      select 3,'怒';

语法二：
insert into 表名
set 列名=值，列名=值，...



列和值必须匹配
可以省略列，默认所有列，

*/

INSERT INTO stud (id,NAME)
VALUES(8,"道8"),(7,"道7"),(9,"道9"),(10,"道10");

INSERT INTO stud (id,NAME)
VALUES(1,'道');

INSERT INTO stud (NAME,id)
VALUES("天",2);

INSERT INTO stud 
VALUES(4,"创新");


INSERT INTO stud
SET id=5,NAME='选择';

INSERT INTO stud
SET id=6;


SELECT * FROM stud;

# 不可以为null的列必须插入值
INSERT INTO stud (id) -- 这个表没有设不允许为null的情况
VALUES(3);

INSERT INTO stud (NAME)
VALUES('3');

# 修改语句
/*
1.修改单表的记录
语法：
	update 表名
	set 列 = 值，...
	【where 筛选条件】；

2.修改多表的记录
语法：
	update 表名1 【别名】，表名2 【别名】
	set 列=值,...
	where 连接条件
	and 筛选条件;
	
	c99
	update 表名1 【别名】
	inner|left|right join 表名2 【别名】
	on 连接条件
	set 列=值,...
	where 筛选条件;

*/
SELECT * FROM stud;

UPDATE stud
SET NAME='测试'
WHERE id=1;


UPDATE boys bo
INNER JOIN beauty b
ON bo.id = b.friend_id
SET b.phone='1444'
WHERE bo.boyName='张无尽';


UPDATE boys bo
RIGHT JOIN beauty b
ON bo.id = b.friend_id
SET b.boyfriend_id = '2'
WHERE bo.id IS NULL;

# 删掉语句
/*

方法1：delete
语法：
delete from 表名 where 筛选条件;

多表删除




c92
	delete 表1 别名，表2 别名
	from 表1 别名，表2别名
	where 连接条件
	and 筛选条件


	
方法2：truncate
语法：truncate table 表名;
	
truncate 删除无返回值，delete 删除有返回值
delete 删除后自增从断点开始，truncate 从1开始
delete 删除后有回滚，truncate 无

*/
SELECT * FROM stud;
DELETE FROM stud
WHERE id=10;

DELETE b  -- 删除beauty表中的信息
FROM beauty b
INNER JOIN boys bo 
ON b.briend_id = bo.id
WHERE
bo.boyNmae='张无尽'

DELETE b，bo  -- 删除beauty boys表中的信息
FROM beauty b
INNER JOIN boys bo 
ON b.briend_id = bo.id
WHERE
bo.boyNmae='张无尽'


# 方法2 
TRUNCATE TABLE boys; -- 删除表中所有信息 ，效率高`stud`






CREATE TABLE dao(id INT,
	NAME VARCHAR(10),
	adress VARCHAR(100)
	);
# 数据类型

/*
数值型：
	整形：
	小数：定点数、浮点数

字符型：
	较短的文本：char、varchar
	较长的文本：test、blob(较长的二进制数据)
	
日期型：
	

*/

# 整形
/*
tinyint 1字节
smallint 2
mediumint 3
int、integer 4
bigint 8

超出范围，报错并设临界值

*/

# 设置有无符号
/*
drop table if exists tab;
create table tab(
	leng int,
	leng2 int unsigned
);



drop table if exists tab;
create table tab(
	leng int (7) zerofill, -- 结果是7个填充
	leng2 int unsigned
);
*/

# 小数
/*
float 4
double 8

定点数类型：
dec(m,d)
decimal(m,d) 
最大数范围与double一致，精度更高

d 小数点后的数

m 小数点+前后 一共多少

m d都可以省略
*/
DROP TABLE IF EXISTS s;
CREATE TABLE s(
	datas DECIMAL(5,2)

);



INSERT INTO s 
VALUES(12345.56);
INSERT INTO s 
VALUES(123.5);
INSERT INTO s 
VALUES(1.2356);

SELECT * FROM s;



# 字符型
/*
varchar(m) 可变 低
char(m) 固定 效率高
m: 最大字符数

text
blob


bit 

enum : 枚举
create table s(
		s1 enum('a','b','c')
	);

Set 集合

*/




# 日期型
/*

	date 4字节 最小值 1000-01-01  最大值 9999-12-31
	datetiime 8 1000-01-01 00:00:00 9999-12-31 23:59:59
	timestamp 4 19700104080001 2038年某一个时刻
	time 3 -838:59:59 838:59:59
	year 1 1901 2155


*/


# 事务 要么全部执行，要么不执行

SHOW VARIABLES LIKE 'autocommit';

SHOW ENGINES;


# 显示事务

# 1.开始事务
SET autocommit = 0; -- 前提 关闭
START TRANSACTION;
# 2.编写sql语句
# insert update ..

# 3.结束事务
#commit;提交事务
#rollback;回滚事务
# 多表查询
/*
	笛卡尔乘积 ：表1 有m行，表2 有n行 结果 = n*m 行
	发生原因：没有有效的连接条件
	如何避免：有效的连接条件

	分类：
	内连接
		等值连接 inner join on
		非等值连接
		自连接
	外连接 : 查询一个表中有，另一个表没有的记录
		
		左外连接 left outer join 左边是主表 on 
		右外连接 right 右边是主表
		全外连接= 内连接结果+表1有表2无+表1无表2有
		
	交叉连接
		
	
*/


# 等值连接
SELECT NAME,boyName FROM boys,beauty 
	WHERE beauty.boyfriend_id = boys.id;
	
# 非等值连接
SELECT salary,grade_level 
FROM employee e,job_grade g  
WHERE salary 
BETWEEN g.lowest_sal AND g.highest_sal
ORDER BY DESC;

# 自连接 自己连接自己
SELECT e.employee_id,e.last_name,e.first_name,m.employee_id,m.last_name
FROM employee e,employee m;
WHERE e.manger_id = m.employee_id;

# c99 语法 inner join on 等值连接
SELECT e.employee_id,e.last_name,e.first_name,m.employee_id,m.last_name
FROM employee e
INNER JOIN department d
ON d.department_id = e.employee_id;

# 查询男朋友 不在男神表的女神名
SELECT n.name,m.* 
FROM beauty n
LEFT OUTER JOIN boyfriends m
ON n.boyfriend_id = m.id

# 全外连接 -- 不支持
SELECT b.*,bo.*
FROM beauty b
FULL OUTER JOIN boys bo
ON b.boyfriend_id = bo.id;

# 交叉连接 *
SELECT b.*,bo.*
FROM beauty b
CROSS JOIN boys bo;

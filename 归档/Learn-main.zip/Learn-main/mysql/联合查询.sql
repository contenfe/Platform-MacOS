/*
联合查询：要查询的结果来自于多个表，且多个表没有直接的连接关系，但查询的信息一致

查询列数必须一致
查询的每一列的联系和顺序最好一致

*/

# 查询中国用户中男性的信息以及外国用户中男性的用户信息
SELECT id,came,csex FROM t_ca WHERE csex='男'
UNION
SELECT t_id,tName,tGender FROM t_ua WHERE tGender='male';
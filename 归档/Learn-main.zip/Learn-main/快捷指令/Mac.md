<!--
 * @Descripttion:  mac快捷键
 * @version: 
 * @Author: 秦武胜
 * @Date: 2021-11-25 16:44:22
 * @LastEditors: 秦武胜
 * @LastEditTime: 2021-11-30 20:31:29
-->
代码提示 alt+cmd+/
显示隐藏文件 cmd+shift+.
代码格式化 alt+shift+f
插件：
    头/函数注释 mac：ctrl+cmd+i/t,
